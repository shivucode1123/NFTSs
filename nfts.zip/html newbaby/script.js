/* 4. prompt the user 5 times.store them in an array and print thne array in reverse order
let arr=[];
for (let i=0; i<5; i++){
    let a = prompt("give a valid input");
     arr.push(a);
}console.log("Inputs in reverse order:")
    console.log(arr.reverse());*/
